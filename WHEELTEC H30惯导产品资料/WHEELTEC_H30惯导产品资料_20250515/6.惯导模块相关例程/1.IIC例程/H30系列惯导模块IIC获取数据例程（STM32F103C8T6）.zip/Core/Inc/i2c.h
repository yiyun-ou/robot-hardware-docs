/**
  ******************************************************************************
  * @file    i2c.h
  * @brief   This file contains all the function prototypes for
  *          the i2c.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __I2C_H__
#define __I2C_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN Private defines */
typedef struct
{
	float acc_x;		/*���ٶ�, unit is m/s2*/
	float acc_y;
	float acc_z;

	float gyro_x;		/*������, unit is dps(��/s) */
	float gyro_y;	
	float gyro_z;	

	float mag_x;		/*�����ƹ�һ��ֵ, �޵�λ*/
	float mag_y;	
	float mag_z;		
	float mag_raw_x;	/*������ԭʼֵ��mGauss*/
	float mag_raw_y;	
	float mag_raw_z;	

	float pitch;		/*ŷ���ǣ���λΪ��*/
	float roll;
	float yaw;
	
	float q0;			/*��Ԫ�����޵�λ*/
	float q1;
	float q2;
	float q3;	
}sensor_info_t;

#define I2C_SLAVE_ADDR					(unsigned char)0x6A

#define I2C_ACC_REG_ADDR				(unsigned char)0x10		/*Register for reading acceleration data*/
#define I2C_GYRO_REG_ADDR				(unsigned char)0x20		/*Register for reading gyroscope data*/
#define I2C_MAG_NORM_REG_ADDR			(unsigned char)0x30		/*Register for reading magnetic normalization data*/
#define I2C_MAG_RAW_REG_ADDR			(unsigned char)0x31		/*Register for reading magnetic raw data*/
#define I2C_EULER_REG_ADDR				(unsigned char)0x40		/*Register for reading euler data and data order is pitch/roll/yaw */
#define I2C_QUATERNION_REG_ADDR			(unsigned char)0x41		/*Register for readingquaternion data */

#define I2C_ACC_DATA_LEN				(unsigned short)12		
#define I2C_GYRO_DATA_LEN				(unsigned short)12	
#define I2C_MAG_NORM_DATA_LEN			(unsigned short)12	
#define I2C_MAG_RAW_DATA_LEN			(unsigned short)12		
#define I2C_EULER_DATA_LEN				(unsigned short)12		
#define I2C_QUATERNIONREG_DATA_LEN		(unsigned short)16

/*factor for sensor data*/
#define I2C_NOT_MAG_DATA_FACTOR			0.000001f
#define I2C_MAG_RAW_DATA_FACTOR			0.001f
/* USER CODE END Private defines */

void MX_I2C1_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __I2C_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
