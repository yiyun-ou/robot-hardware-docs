/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "delay.h"
#include "oled.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
sensor_info_t g_sensor_info;
uint8_t g_i2c_rx_EULERbuf[12] = {0x00};
uint8_t g_i2c_rx_ACCbuf[12] = {0x00};
uint8_t g_i2c_rx_GYRObuf[12] = {0x00};
uint8_t g_i2c_rx_QUATERNIONbuf[16] = {0x00};
uint8_t int_flag,i;
uint8_t Angle_Raw[2];
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  delay_init();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  OLED_Init();
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	 if(int_flag==1)
	{
		//ŷ����
		HAL_I2C_Mem_Read(&hi2c1,I2C_SLAVE_ADDR,I2C_EULER_REG_ADDR,I2C_MEMADD_SIZE_8BIT,g_i2c_rx_EULERbuf,I2C_EULER_DATA_LEN,1);
		g_sensor_info.pitch = *((int *)g_i2c_rx_EULERbuf) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.roll = *((int *)(g_i2c_rx_EULERbuf + 4)) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.yaw = *((int *)(g_i2c_rx_EULERbuf + 8)) * I2C_NOT_MAG_DATA_FACTOR;
		//�Ǽ��ٶ�
		HAL_I2C_Mem_Read(&hi2c1,I2C_SLAVE_ADDR,I2C_ACC_REG_ADDR,I2C_MEMADD_SIZE_8BIT,g_i2c_rx_ACCbuf,I2C_ACC_DATA_LEN,1);
		g_sensor_info.acc_x = *((int *)g_i2c_rx_ACCbuf) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.acc_y = *((int *)(g_i2c_rx_ACCbuf + 4)) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.acc_z = *((int *)(g_i2c_rx_ACCbuf + 8)) * I2C_NOT_MAG_DATA_FACTOR;
		//���ٶ�
		HAL_I2C_Mem_Read(&hi2c1,I2C_SLAVE_ADDR,I2C_GYRO_REG_ADDR,I2C_MEMADD_SIZE_8BIT,g_i2c_rx_GYRObuf,I2C_GYRO_DATA_LEN,1);
		g_sensor_info.gyro_x = *((int *)g_i2c_rx_GYRObuf) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.gyro_y = *((int *)(g_i2c_rx_GYRObuf + 4)) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.gyro_z = *((int *)(g_i2c_rx_GYRObuf + 8)) * I2C_NOT_MAG_DATA_FACTOR;
		//��Ԫ��
		HAL_I2C_Mem_Read(&hi2c1,I2C_SLAVE_ADDR,I2C_QUATERNION_REG_ADDR,I2C_MEMADD_SIZE_8BIT,g_i2c_rx_QUATERNIONbuf,I2C_QUATERNIONREG_DATA_LEN,1);
		g_sensor_info.q0 = *((int *)g_i2c_rx_QUATERNIONbuf) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.q1 = *((int *)(g_i2c_rx_QUATERNIONbuf + 4)) * I2C_NOT_MAG_DATA_FACTOR;
		g_sensor_info.q2 = *((int *)(g_i2c_rx_QUATERNIONbuf + 8)) * I2C_NOT_MAG_DATA_FACTOR;
        g_sensor_info.q3 = *((int *)(g_i2c_rx_QUATERNIONbuf + 12)) * I2C_NOT_MAG_DATA_FACTOR;
	}
	oled_show();
	printf("%f\n\r",g_sensor_info.q0);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_PIN_12 == GPIO_Pin)	/*YIS160 INT*/
	{
		int_flag = 1;
	}
}
int myabs(int a)
{ 		   
	int temp;
	if(a<0)  temp=-a;  
	else temp=a;
	return temp;
}
void oled_show(void)
{
	//ŷ����
	if(g_sensor_info.pitch>0)
	   OLED_ShowString(0,0,"P:");
	else
	   OLED_ShowString(0,0,"P:-");
	OLED_ShowNumber(25,0,myabs(g_sensor_info.pitch),3,12);
	if(g_sensor_info.roll>0)
	   OLED_ShowString(0,10,"R:");
	else
		OLED_ShowString(0,10,"R:-");
	OLED_ShowNumber(25,10,myabs(g_sensor_info.roll),3,12);
	if(g_sensor_info.yaw>0)
	    OLED_ShowString(0,20,"Y:");
	else
		OLED_ShowString(0,20,"Y:-");
	OLED_ShowNumber(25,20,myabs(g_sensor_info.yaw),3,12);
	
	//���ٶ�
	if(g_sensor_info.gyro_x>0)
	   OLED_ShowString(60,0,"G-X:");
	else
	   OLED_ShowString(60,0,"G-X:-");
	OLED_ShowNumber(90,0,myabs(g_sensor_info.gyro_x),3,12);
	if(g_sensor_info.roll>0)
	   OLED_ShowString(60,10,"G-Y:");
	else
		OLED_ShowString(60,10,"G-Y:-");
	OLED_ShowNumber(90,10,myabs(g_sensor_info.gyro_y),3,12);
	if(g_sensor_info.yaw>0)
	    OLED_ShowString(60,20,"G-Z:");
	else
		OLED_ShowString(60,20,"G-Z:-");
	OLED_ShowNumber(90,20,myabs(g_sensor_info.gyro_z),3,12);
	
	//�Ǽ��ٶ�
	if(g_sensor_info.acc_x>0)
	    OLED_ShowString(0,30,"A-X:");
	else
		OLED_ShowString(0,30,"A-X:-");
	OLED_ShowNumber(30,30,myabs(g_sensor_info.acc_x),2,12);
		if(g_sensor_info.acc_y>0)
	    OLED_ShowString(0,40,"A-Y:");
	else
		OLED_ShowString(0,40,"A-Y:-");
	OLED_ShowNumber(30,40,myabs(g_sensor_info.acc_y),2,12);
		if(g_sensor_info.acc_z>0)
	    OLED_ShowString(0,50,"A-Z:");
	else
		OLED_ShowString(0,50,"A-Z:-");
	OLED_ShowNumber(30,50,myabs(g_sensor_info.acc_z),2,12);
	
	//��Ԫ��
	if(g_sensor_info.q0>0)
	    OLED_ShowString(60,30,"Q0: 0.");
	else
		OLED_ShowString(60,30,"Q0:-0.");
	OLED_ShowNumber(105,30,myabs(g_sensor_info.q0*100/10)%10,1,12);
	OLED_ShowNumber(113,30,myabs(g_sensor_info.q0*100)%10,1,12);
	if(g_sensor_info.acc_y>0)
	    OLED_ShowString(60,40,"Q1: 0.");
	else
		OLED_ShowString(60,40,"Q1:-0.");
	OLED_ShowNumber(105,40,myabs(g_sensor_info.q1*10)&10,1,12);
	OLED_ShowNumber(113,40,myabs(g_sensor_info.q1*100)%100,1,12);
		if(g_sensor_info.acc_z>0)
	    OLED_ShowString(60,50,"Q2: 0.");
	else
		OLED_ShowString(60,50,"Q2:-0.");
	OLED_ShowNumber(105,50,myabs(g_sensor_info.q2*10)&10,1,12);
	OLED_ShowNumber(113,50,myabs(g_sensor_info.q2*100)&10,1,12);
	
	OLED_Refresh_Gram();
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
